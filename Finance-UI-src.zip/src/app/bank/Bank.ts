export class Bank{
    bankType :  string|undefined;
    regId    :  number|undefined;
    ifscCode :  string|undefined;  
}