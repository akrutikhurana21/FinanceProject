import { Component, OnInit } from '@angular/core';
import { Transaction } from './Transaction';
import { TransactionService } from './transaction.service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  constructor(private tranServ:TransactionService) { }
  usersession: any;
  cardNo=0;

  ngOnInit(): void {
    this.usersession = sessionStorage.getItem('myuser');
    this.usersession = JSON.parse(this.usersession);
    this.cardNo = this.usersession.cardNo;
    this.findTransactions(this.cardNo);
  
   console.log(this.cardNo+"  ----  "+ this.usersession.cardNo);
  }

  tempTran:Transaction[] |undefined;  //created an object of departments
  findTransactions(cardNo:number){
      this.tranServ.findTransactionByCardservice(cardNo).subscribe((data:any)=>{
        if (data!=null) 
        {
          this.tempTran=data;
         console.log(data);
        }
        else{
          alert('unable to fetch');
        }
        })
  }

}
