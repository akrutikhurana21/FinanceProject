import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Transaction } from './Transaction';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor(private myHttp:HttpClient) { }

  
findTransactionByCardservice(CardNo: number): Observable<Transaction[]> {
  return this.myHttp.get<Transaction[]>("http://localhost:8080/getTransByCard/"+CardNo);
   
}
}
