export class Transaction{
    transId: number|undefined;
    dueAmt: number|undefined;
    installment: number|undefined;
    monthNo: number|undefined;
    transDate: string|undefined;
    ordId:number|undefined;
}