export class Card {
    cardNo: number |undefined;
    cardLimit: number |undefined;
    custName: string |undefined;
    endDate: string |undefined;
    startDate: string |undefined;
    cardType: string |undefined;
}
