export class Order{
    ordId :number |undefined;
    orderDate :Date |undefined;
    emiMonths :number |undefined; 
    emiPerMonth :number |undefined;
    quantity: number |undefined;
    remainingAmount: number |undefined;
    totalCost: number |undefined;
}