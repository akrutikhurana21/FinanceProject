import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProdserviceService } from '../prodservice.service';
import { Product } from '../product/Product';

@Component({
  selector: 'app-product-page',
  templateUrl: './product-page.component.html',
  styleUrls: ['./product-page.component.css']
})
export class ProductPageComponent implements OnInit { 

  emi: any;
  mySelect: any;
  myQuantity:any;
  
  myProd: Product = new Product();

  constructor(private prodServ:ProdserviceService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    let prd: any;
    
    prd = sessionStorage.getItem('product');

     this.myProd = JSON.parse(prd);
  }
  selectChange() { 
    let price: any;
    let month: any;
    let quantity:any;

    let totalPrice :any;

    
    price = this.myProd.productPrice ;
    month = this.mySelect;
    quantity=this.myQuantity;
  
    totalPrice=price*quantity;
    this.emi = totalPrice/month;

  }
}
