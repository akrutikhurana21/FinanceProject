
export class Product{
      productId :number |undefined;
      productName :string |undefined;
      productPrice :number |undefined; 
      imageUrl: string| undefined;
}