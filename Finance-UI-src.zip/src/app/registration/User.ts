export class User{
    
    regId : number|undefined;
    address : string|undefined;
    adharCard : number|undefined;
    cardType : string|undefined;
    dob: string |undefined;
    emailId: string|undefined;
    name: string|undefined;
    password : string|undefined;
    phoneNo : number|undefined;
    registrationDate: string |undefined;
    username : string|undefined;
    
}