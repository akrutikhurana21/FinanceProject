import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  hide=true;
  show=true;
  isLoggedIn:any
  title = 'FinanceProject';

  constructor(
    private route: ActivatedRoute,
    private router: Router) {
      this.router.navigate(["/index"]);
     }

     checkUSerLogIn():any{
       this.isLoggedIn= sessionStorage.getItem("myuser");
       return this.isLoggedIn;

     }
     
     Content(){
       if(this.checkUSerLogIn()){
        this.hide=true;
       this.show=false;
       }else{
        this.hide=false;
        this.show=true;
       }
       
     }

}
